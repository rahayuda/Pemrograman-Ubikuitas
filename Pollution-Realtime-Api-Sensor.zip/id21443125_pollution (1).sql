-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 09, 2023 at 05:52 AM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21443125_pollution`
--

-- --------------------------------------------------------

--
-- Table structure for table `pollutant`
--

CREATE TABLE `pollutant` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ramalan` varchar(11) DEFAULT NULL,
  `ramname` varchar(255) DEFAULT NULL,
  `aqi` varchar(10) DEFAULT NULL,
  `lat` varchar(11) DEFAULT NULL,
  `lon` varchar(11) DEFAULT NULL,
  `aqi_name` varchar(255) DEFAULT NULL,
  `so2` varchar(10) DEFAULT NULL,
  `no2` varchar(10) DEFAULT NULL,
  `pm10` varchar(10) DEFAULT NULL,
  `pm2_5` varchar(10) DEFAULT NULL,
  `o3` varchar(10) DEFAULT NULL,
  `co` varchar(10) DEFAULT NULL,
  `time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pollutant`
--

INSERT INTO `pollutant` (`Id`, `name`, `ramalan`, `ramname`, `aqi`, `lat`, `lon`, `aqi_name`, `so2`, `no2`, `pm10`, `pm2_5`, `o3`, `co`, `time`) VALUES
(2, 'Denpasar Lumintang', '67', 'Moderate', '67', NULL, NULL, 'Moderate', '25', '6', '18', '67', '13', '0', '2023-10-24 12:00:00'),
(4, 'Denpasar Lumintang', '67', 'Moderate', '73', NULL, NULL, 'Moderate', '25', '6', '21', '73', '13', '0', '2023-10-25 12:00:00'),
(5, 'Denpasar Lumintang', '68.8', 'Moderate', '62', NULL, NULL, 'Moderate', '25', '6', '16', '62', '13', '0', '2023-10-26 12:00:00'),
(6, 'Denpasar Lumintang', '66.76', 'Moderate', '67', NULL, NULL, 'Moderate', '23', '5', '18', '67', '13', '0', '2023-10-27 12:00:00'),
(7, 'Denpasar Lumintang', '66.832', 'Moderate', '65', NULL, NULL, 'Moderate', '24', '6', '17', '65', '14', '0', '2023-10-28 12:00:00'),
(8, 'Denpasar Lumintang', '66.2824', 'Moderate', '64', NULL, NULL, 'Moderate', '24', '6', '17', '64', '14', '0', '2023-10-29 12:00:00'),
(9, 'Denpasar Lumintang', '65.59768', 'Moderate', '64', NULL, NULL, 'Moderate', '24', '6', '17', '64', '13', '0', '2023-10-30 12:00:00'),
(10, 'Denpasar Lumintang', '65.118376', 'Moderate', '65', NULL, NULL, 'Moderate', '24', '5', '17', '65', '13', '0', '2023-10-31 12:00:00'),
(11, 'Denpasar Lumintang', '65.0828632', 'Moderate', '82', NULL, NULL, 'Moderate', '24', '5', '24', '82', '13', '0', '2023-11-01 12:00:00'),
(12, 'Denpasar Lumintang', '70.15800424', 'Moderate', '70', NULL, NULL, 'Moderate', '25', '5', '19', '70', '13', '0', '2023-11-02 12:00:00'),
(13, 'Denpasar Lumintang', '70.11', 'Moderate', '55', NULL, NULL, 'Moderate', '48', '12', '13', '55', '13', '0', '2023-11-03 12:00:00'),
(14, 'Denpasar Lumintang', '65.58', 'Moderate', '61', NULL, NULL, 'Moderate', '48', '12', '15', '61', '33', '0', '2023-11-04 12:00:00'),
(15, 'Denpasar Lumintang', '64.21', 'Moderate', '60', NULL, NULL, 'Moderate', '48', '11', '15', '60', '31', '0', '2023-11-05 12:00:00'),
(16, 'Denpasar Lumintang', '62.95', 'Moderate', '64', NULL, NULL, 'Moderate', '49', '12', '17', '64', '33', '0', '2023-11-06 12:00:00'),
(17, 'Denpasar Lumintang', '63.27', 'Moderate', '55', NULL, NULL, 'Moderate', '24', '5', '13', '55', '13', '0', '2023-11-07 12:00:00'),
(18, 'Denpasar Lumintang', '60.79', 'Moderate', '63', NULL, NULL, 'Moderate', '23', '5', '16', '63', '12', '0', '2023-11-08 12:00:00'),
(19, 'Denpasar Lumintang', '61.45', 'Moderate', '60', NULL, NULL, 'Moderate', '24', '5', '15', '60', '12', '0', '2023-11-09 12:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pollutant`
--
ALTER TABLE `pollutant`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pollutant`
--
ALTER TABLE `pollutant`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
